import React from "react";
import Navbar from "./Navbar";

function Home() {
  const styles = {
    container: {
      fontFamily: "Arial, sans-serif",
      textAlign: "center",
      color: "#fff",
      backgroundImage: "url('https://via.placeholder.com/1920x1080')",
      backgroundSize: "cover",
      backgroundPosition: "center",
      height: "100vh",
      margin: 0,
      padding: "0 20px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
    },
    profileImage: {
      width: "150px",
      height: "150px",
      borderRadius: "50%",
      border: "5px solid #fff",
      marginBottom: "20px",
      animation: "bounce 2s infinite",
    },
    title: {
      fontSize: "2.5rem",
      margin: "10px 0",
      textShadow: "2px 2px 10px rgba(0, 0, 0, 0.7)",
    },
    description: {
      fontSize: "1.2rem",
      maxWidth: "600px",
      margin: "0 auto 30px",
      lineHeight: "1.6",
      textShadow: "1px 1px 5px rgba(0, 0, 0, 0.5)",
    },
    socialLinks: {
      display: "flex",
      gap: "15px",
    },
    socialIcon: {
      width: "40px",
      height: "40px",
      borderRadius: "50%",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "#fff",
      color: "#333",
      textDecoration: "none",
      fontSize: "1.2rem",
      boxShadow: "0 4px 6px rgba(0, 0, 0, 0.2)",
      transition: "transform 0.3s, box-shadow 0.3s",
    },
    socialIconHover: {
      transform: "scale(1.1)",
      boxShadow: "0 6px 10px rgba(0, 0, 0, 0.3)",
    },
    "@keyframes bounce": {
      "0%, 100%": { transform: "translateY(0)" },
      "50%": { transform: "translateY(-10px)" },
    },
  };

  return (
    <div style={styles.container}>
      <Navbar />
      <img
        src="https://via.placeholder.com/150"
        alt="Profile"
        style={styles.profileImage}
      />
      <h1 style={styles.title}>Hello, I'm [Your Name]</h1>
      <p style={styles.description}>
        I am a passionate web developer who loves crafting beautiful, functional
        websites. Explore my portfolio to see my work.
      </p>
      <div style={styles.socialLinks}>
        <a
          href="https://github.com"
          target="_blank"
          rel="noopener noreferrer"
          style={{ ...styles.socialIcon }}
          onMouseOver={(e) => Object.assign(e.target.style, styles.socialIconHover)}
          onMouseOut={(e) => Object.assign(e.target.style, styles.socialIcon)}
        >
          G
        </a>
        <a
          href="https://linkedin.com"
          target="_blank"
          rel="noopener noreferrer"
          style={{ ...styles.socialIcon }}
          onMouseOver={(e) => Object.assign(e.target.style, styles.socialIconHover)}
          onMouseOut={(e) => Object.assign(e.target.style, styles.socialIcon)}
        >
          L
        </a>
        <a
          href="https://twitter.com"
          target="_blank"
          rel="noopener noreferrer"
          style={{ ...styles.socialIcon }}
          onMouseOver={(e) => Object.assign(e.target.style, styles.socialIconHover)}
          onMouseOut={(e) => Object.assign(e.target.style, styles.socialIcon)}
        >
          T
        </a>
      </div>
    </div>
  );
}

export default Home;
