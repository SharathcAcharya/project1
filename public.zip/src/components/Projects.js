import React, { Component } from 'react'

export class ChangeTextCaseWithTheme extends Component {
  constructor() {
    super();
    this.state = {
      text: '',
      theme: 'light'
    };
    this.handleChange = this.handleChange.bind(this);
    this.changeTextToLowerCase = this.changeTextToLowerCase.bind(this);
    this.changeTextToUpperCase = this.changeTextToUpperCase.bind(this);
    this.toggleTheme = this.toggleTheme.bind(this);
}
handleChange(event) {
    this.setState({ text: event.target.value });
}

  render() {
    return (
      <div>Projects</div>
    )
  }
}

export default Projects